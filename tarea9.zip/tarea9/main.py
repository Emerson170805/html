from ultralytics import YOLO

def entrenar_yolo():
    epochs = 20  # Número fijo de épocas

    # Cargar modelo base preentrenado YOLOv8n (nano)
    model = YOLO('yolov8n.pt')

    # Iniciar entrenamiento con archivo YAML y parámetros ingresados
    model.train(
        data='/var/www/html/html/tarea9/data_set/data.yaml',  # Ruta a tu archivo YAML
        epochs=epochs,
        imgsz=640,                  # Tamaño de imagen (puedes cambiarlo)
        batch=16,                   # Tamaño de batch (ajustar según GPU/memoria)
        workers=4                   # Número de procesos para cargar datos
    )

if __name__ == "__main__":
    entrenar_yolo()
