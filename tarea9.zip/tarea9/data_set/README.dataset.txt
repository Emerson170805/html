# facial expression non english > 2025-01-19 11:14pm
https://universe.roboflow.com/facial-expression-recognition-d8apz/facial-expression-non-english

Provided by a Roboflow user
License: CC BY 4.0

